package DiagIA;

public class BusqArbol {
    public static void main(String[] args) {
        Nodo n1 = new Nodo("A", null, null);
        Nodo n2 = new Nodo("B", null, null);
        Nodo n3 = new Nodo("C", null, null);
        Nodo n4 = new Nodo("D", null, null);
        Nodo n5 = new Nodo("E", null, null);

        n1.izq = n2;
        n1.der = n3;
        n2.izq = n4;
        n2.der = n5;

        Arbol arbol = new Arbol(n1);

        String nombreBus = "D";
        Nodo nodoEncontrado = arbol.buscarNodo(nombreBus);

        if (nodoEncontrado != null) {
            System.out.println("Nodo encontrado: " + nodoEncontrado.nombre);
        } else {
            System.out.println("Nodo no encontrado");
        }
    }
}