package DiagIA;

public class Nodo{
    String nombre;
    Nodo der;
    Nodo izq;

    public Nodo(String nombre, Nodo der, Nodo izq){
        this.nombre = nombre;
        der = null;
        izq = null;
    }
}