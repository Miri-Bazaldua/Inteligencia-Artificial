package DiagIA;

public class Arbol {
    private Nodo raiz;

    public Arbol(Nodo raiz) {
        this.raiz = raiz;
    }

    public boolean vacio() {
        return raiz == null;
    }

    public Nodo buscarNodo(String nombre) {
        return buscarN(raiz, nombre);
    }

    public Nodo buscarN(Nodo n, String nombre) {
        if (n == null) {
            return null;
        }
        if (n.nombre.equals(nombre)) {
            return n;
        }
        Nodo encontrado = buscarN(n.izq, nombre);
        if (encontrado != null) {
            return encontrado;
        }
        return buscarN(n.der, nombre);
    }
}