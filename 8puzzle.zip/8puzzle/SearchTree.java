import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;

//Árbol de búsqueda del 8-puzzle.

public class SearchTree {
    Node root;
    String goalState;
    String initialState;

    // Contadores de la búsqueda en profundidad limitada. Son atributos de la clase
    // porque el método recursivo los va actualizando en cada llamada.
    int time;
    int maxDepth;

    public SearchTree(String initialState, String goalState) {
        this.initialState = initialState;
        this.goalState = goalState;
        // El nodo raíz corresponde al estado inicial y no tiene padre.
        this.root = new Node(initialState, null);
    }

    // Búsqueda primero en anchura (BFS). Explora por niveles usando una cola FIFO.
    public void breadthFirstSearch() {
        System.out.println("===== Breadth First Search =====");

        // Nodos procesados y mayor tamaño que llegó a tener la cola.
        int time = 0;
        int maxQueue = 0;
        // Estados visitados, para no volver a procesar un tablero ya explorado.
        Set<String> visited = new HashSet<String>();
        Node currentNode = root;
        Node result = null;
        Queue<Node> queue = new LinkedList<>();

        queue.add(currentNode);
        long startTime = System.nanoTime();

        while (!queue.isEmpty()) {
            time++;
            currentNode = queue.poll();
            visited.add(currentNode.getState());

            if(currentNode.getState().equals(goalState)) {
                result = currentNode;
                break;
            }

            // Genera los sucesores y encola los que no han sido visitados.
            List<Node> children = NodeUtils.generateChildren(currentNode);

            for (Node child : children) {
                if (!visited.contains(child.getState()))
                    queue.add(child);
            }

            if (queue.size() > maxQueue)
                maxQueue = queue.size();
        }

        // Se detiene el cronómetro antes de imprimir para medir solo la búsqueda.
        long endTime = System.nanoTime();

        if (result != null) {
            System.out.println("Goal state found: " + result.getState());
            printPath(result);
            System.out.println("Profundidad de la solucion: " + result.getDepth());
        } else {
            System.out.println("No se encontro la solucion");
        }

        System.out.println("--- Datos estadisticos ---");
        System.out.println("Time: " + time);
        System.out.println("Estados visitados: " + visited.size());
        System.out.println("Queue: " + queue.size());
        System.out.println("Max Queue: " + maxQueue);
        System.out.println("Tiempo real (ms): " + (endTime - startTime) / 1000000.0);
        System.out.println();
    }

    // Búsqueda primero en profundidad (DFS).
    // Mismo procedimiento que BFS, pero con una pila (LIFO) en lugar de una cola,
    // por lo que sigue una rama hasta el fondo antes de probar otra.
    public void depthFirstSearch() {
        System.out.println("--- Depth First Search ---");

        int time = 0;
        int maxStack = 0;
        Set<String> visited = new HashSet<String>();
        Node currentNode = root;
        Node result = null;
        Stack<Node> stack = new Stack<>();

        stack.push(currentNode);
        long startTime = System.nanoTime();

        while (!stack.isEmpty()) {
            time++;

            // Extrae el último nodo agregado a la pila (LIFO).
            currentNode = stack.pop();
            visited.add(currentNode.getState());

            if(currentNode.getState().equals(goalState)) {
                result = currentNode;
                break;
            }

            // El último sucesor apilado será el siguiente en procesarse.
            List<Node> children = NodeUtils.generateChildren(currentNode);

            for (Node child : children) {
                if (!visited.contains(child.getState()))
                    stack.push(child);
            }

            if (stack.size() > maxStack)
                maxStack = stack.size();
        }

        long endTime = System.nanoTime();

        if (result != null) {
            System.out.println("Goal state found: " + result.getState());
            printPath(result);
            System.out.println("Profundidad de la solucion: " + result.getDepth());
        } else {
            System.out.println("No se encontro la solucion");
        }

        System.out.println("--- Datos estadisticos ---");
        System.out.println("Time: " + time);
        System.out.println("Estados visitados: " + visited.size());
        System.out.println("Stack: " + stack.size());
        System.out.println("Max Stack: " + maxStack);
        System.out.println("Tiempo real (ms): " + (endTime - startTime) / 1000000.0);
        System.out.println();
    }

    public void uniformCostSearch() {
        System.out.println("*** Uniform Cost Search ***");

        int time = 0;
        int maxQueue = 0;
        Set<String> visited = new HashSet<String>();
        // El nodo raíz entra con costo 0.
        Node currentNode = root;
        Node result = null;
        PriorityQueue<Node> queue = new PriorityQueue<>(new NodePriorityComparator());

        queue.add(currentNode);
        long startTime = System.nanoTime();

        while (!queue.isEmpty()) {
            time++;

            currentNode = queue.poll();
            visited.add(currentNode.getState());

            if(currentNode.getState().equals(goalState)) {
                result = currentNode;
                break;
            }

            List<Node> children = NodeUtils.generateChildren(currentNode);

            for (Node child : children) {
                if (!visited.contains(child.getState())) {
                    child.setCost(child.getParent().getCost() + 1);
                    queue.add(child);
                }
            }

            if (queue.size() > maxQueue)
                maxQueue = queue.size();
        }

        long endTime = System.nanoTime();

        if (result != null) {
            System.out.println("Goal state found: " + result.getState());
            printPath(result);
            System.out.println("Profundidad de la solucion: " + result.getDepth());
            System.out.println("Costo de la solucion: " + result.getCost());
        } else {
            System.out.println("No se encontro la solucion");
        }

        System.out.println("--- Datos estadisticos ---");
        System.out.println("Time: " + time);
        System.out.println("Estados visitados: " + visited.size());
        System.out.println("Priority Queue: " + queue.size());
        System.out.println("Max Priority Queue: " + maxQueue);
        System.out.println("Tiempo real (ms): " + (endTime - startTime) / 1000000.0);
        System.out.println();
    }

    public void depthLimitedSearch(int limit) {
        System.out.println("--- Depth Limited Search (limite " + limit + ") ---");

        time = 0;
        maxDepth = 0;

        Set<String> visited = new HashSet<String>();

        long startTime = System.nanoTime();
        Node result = recursiveDLS(root, limit, visited);
        long endTime = System.nanoTime();

        if (result != null) {
            System.out.println("Goal state found: " + result.getState());
            printPath(result);
            System.out.println("Profundidad de la solucion: " + result.getDepth());
        } else {
            System.out.println("No se encontro la solucion con limite " + limit);
        }

        System.out.println("--- Datos estadisticos ---");
        System.out.println("Time: " + time);
        System.out.println("Profundidad maxima alcanzada: " + maxDepth);
        System.out.println("Tiempo real (ms): " + (endTime - startTime) / 1000000.0);
        System.out.println();
    }

    private Node recursiveDLS(Node currentNode, int limit, Set<String> visited) {
        time++;

        if (currentNode.getDepth() > maxDepth)
            maxDepth = currentNode.getDepth();

        if (currentNode.getState().equals(goalState))
            return currentNode;

        if (currentNode.getDepth() >= limit)
            return null;

        visited.add(currentNode.getState());

        List<Node> children = NodeUtils.generateChildren(currentNode);

        for (Node child : children) {
            if (!visited.contains(child.getState())) {
                Node result = recursiveDLS(child, limit, visited);

                if (result != null)
                    return result;
            }
        }

        visited.remove(currentNode.getState());

        return null;
    }

    public void iterativeDeepeningSearch() {
        System.out.println("===== Iterative Deepening Search =====");

        int totalTime = 0;
        int[] timePorLimite = new int[32];
        int ultimoLimite = 0;
        Node result = null;

        long startTime = System.nanoTime();

        for (int limit = 0; limit <= 31; limit++) {
            time = 0;
            maxDepth = 0;

            Set<String> visited = new HashSet<String>();
            result = recursiveDLS(root, limit, visited);

            totalTime += time;
            timePorLimite[limit] = time;
            ultimoLimite = limit;

            if (result != null)
                break;
        }

        long endTime = System.nanoTime();

        for (int limit = 0; limit <= ultimoLimite; limit++) {
            System.out.println("Limite " + limit + " - Time: " + timePorLimite[limit]);
        }

        if (result != null) {
            System.out.println("Goal state found: " + result.getState());
            printPath(result);
            System.out.println("Profundidad de la solucion: " + result.getDepth());
        } else {
            System.out.println("No se encontro la solucion");
        }

        System.out.println("--- Datos estadisticos ---");
        System.out.println("Time (todas las iteraciones): " + totalTime);
        System.out.println("Profundidad maxima alcanzada: " + maxDepth);
        System.out.println("Tiempo real (ms): " + (endTime - startTime) / 1000000.0);
        System.out.println();
    }

    public void bidirectionalSearch() {
        System.out.println("===== Bidirectional Search (opcional) =====");

        int time = 0;
        int maxQueue = 0;
        long startTime = System.nanoTime();

        Map<String, Node> visitedStart = new HashMap<String, Node>();
        Map<String, Node> visitedGoal = new HashMap<String, Node>();

        Queue<Node> queueStart = new LinkedList<>();
        Queue<Node> queueGoal = new LinkedList<>();

        Node goalRoot = new Node(goalState, null);

        queueStart.add(root);
        visitedStart.put(root.getState(), root);

        queueGoal.add(goalRoot);
        visitedGoal.put(goalRoot.getState(), goalRoot);


        Node meetStart = null;
        Node meetGoal = null;
        
        if (initialState.equals(goalState)) {
            meetStart = root;
            meetGoal = goalRoot;
        }

        while (meetStart == null && !queueStart.isEmpty() && !queueGoal.isEmpty()) {

            int levelSize = queueStart.size();

            for (int i = 0; i < levelSize && meetStart == null; i++) {
                time++;

                Node currentNode = queueStart.poll();
                List<Node> children = NodeUtils.generateChildren(currentNode);

                for (Node child : children) {
                    if (visitedGoal.containsKey(child.getState())) {
                        meetStart = child;
                        meetGoal = visitedGoal.get(child.getState());
                        break;
                    }

                    if (!visitedStart.containsKey(child.getState())) {
                        visitedStart.put(child.getState(), child);
                        queueStart.add(child);
                    }
                }
            }

            if (meetStart != null)
                break;

            levelSize = queueGoal.size();

            for (int i = 0; i < levelSize && meetGoal == null; i++) {
                time++;

                Node currentNode = queueGoal.poll();
                List<Node> children = NodeUtils.generateChildren(currentNode);

                for (Node child : children) {
                    if (visitedStart.containsKey(child.getState())) {
                        meetGoal = child;
                        meetStart = visitedStart.get(child.getState());
                        break;
                    }

                    if (!visitedGoal.containsKey(child.getState())) {
                        visitedGoal.put(child.getState(), child);
                        queueGoal.add(child);
                    }
                }
            }

            if (queueStart.size() + queueGoal.size() > maxQueue)
                maxQueue = queueStart.size() + queueGoal.size();
        }

        long endTime = System.nanoTime();

        if (meetStart != null) {
            System.out.println("Goal state found: " + goalState);
            System.out.println("Estado de encuentro: " + meetStart.getState());

            printPath(meetStart);

            Node node = meetGoal.getParent();

            while (node != null) {
                System.out.println(NodeUtils.formatState(node.getState()));
                node = node.getParent();
            }

            System.out.println(
                "Profundidad de la solucion: "
                + (meetStart.getDepth() + meetGoal.getDepth())
            );

        } else {
            System.out.println("No se encontro la solucion");
        }

        System.out.println("--- Datos estadisticos ---");
        System.out.println("Time: " + time);
        System.out.println("Estados visitados: " + (visitedStart.size() + visitedGoal.size()));
        System.out.println("Queue (ambas): " + (queueStart.size() + queueGoal.size()));
        System.out.println("Max Queue (ambas): " + maxQueue);
        System.out.println("Tiempo real (ms): " + (endTime - startTime) / 1000000.0);
        System.out.println();
    }

    public void printPath(Node node) {
        if (node == null) {
            return;
        }

        printPath(node.getParent());
        System.out.println(NodeUtils.formatState(node.getState()));
    }
}