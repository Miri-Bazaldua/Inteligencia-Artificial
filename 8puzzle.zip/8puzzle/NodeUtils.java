import java.util.ArrayList;
import java.util.List;

/*
 * Utilerías del 8-puzzle. Aquí viven la función sucesor y el formato del tablero.*/
public class NodeUtils {

    // Intercambia dos casillas.
    private static String swapPositions(String state, int pos1, int pos2) {
        char[] arr = state.toCharArray();
        char temp = arr[pos1];
        arr[pos1] = arr[pos2];
        arr[pos2] = temp;
        return new String(arr);
    }

    // Función sucesor. Genera todos los estados que se obtienen al mover el espacio vacío a una casilla adyacente
    public static List<Node> generateChildren(Node parentNode) {

        List<Node> successors = new ArrayList<>();
        int zeroPos = parentNode.getState().indexOf(" ");

        /* Para cada posición del espacio vacío se indican las posiciones con las que puede intercambiarse.*/
        int[][] adjacentPositions = {
            {1, 3},          
            {0, 2, 4},    
            {1, 5},       
            {0, 4, 6},    
            {1, 3, 5, 7}, 
            {2, 4, 8},    
            {3, 7},       
            {4, 6, 8},    
            {5, 7}        
        };

        for (int adjPos : adjacentPositions[zeroPos]) {
            String newState = swapPositions(parentNode.getState(), zeroPos, adjPos);
            successors.add(new Node(newState, parentNode));
        }

        return successors;
    }

    // Convierte la cadena de 9 caracteres en una matriz de 3 x 3 para imprimirlo.
    public static String formatState(String state){
        String formattedState = "";
        for(int i = 0; i < state.length(); i++){
            formattedState += state.charAt(i) + " ";
            if((i + 1) % 3 == 0){
                formattedState += "\n";
            }
        }
        return formattedState;
    }
}